Sube TODO el contenido del ZIP a GitHub Pages. Mantén las carpetas img y sounds junto a index.html.
